
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
      
        <!--Formulario de login-->
        <form action="procesalogin.php" method="POST">
            <p><label> Usuario (*): </label><input type="text" name="loginUsuario"></p>
            <p> <label> Contrase&ntilde;a (*):</label> <input type="Password" name="loginContrasenia"></p>
            <input type="submit" name="loginEnvio" value="Enviar">
        </form>
    </body>
</html>
