<?php
if(isset($_POST['salir'])){
    echo 'Ha decidido cerrar sesi&oacute;n. ¡Vuelva pronto!';
    require_once 'index.php';
    
}

?>

