<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="estilo.css">
        <title>Epd_6_p1</title>
    </head>
    <body>
        <article>
            <section>
                <h1>Opciones</h1>
                <a href="altaAerolinea.php">Alta Aerol&iacute;nea</a>
                <a href="altaVuelos.php">Alta Vuelos</a>
                <a href="informeResumen.php">Informe Resumen</a>
            </section>
        </article>
    </body>
</html>
