-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-11-2017 a las 12:45:57
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `articulos_cientificos`
--
CREATE DATABASE IF NOT EXISTS `articulos_cientificos` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `articulos_cientificos`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulos`
--

CREATE TABLE `articulos` (
  `nom_articulo` varchar(80) NOT NULL,
  `marca_tiempo` int(20) NOT NULL,
  `descripcion_articulo` varchar(100) NOT NULL,
  `nom_usuario` varchar(50) NOT NULL,
  `universidad` varchar(80) NOT NULL,
  `hash_articulo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `articulos`
--

INSERT INTO `articulos` (`nom_articulo`, `marca_tiempo`, `descripcion_articulo`, `nom_usuario`, `universidad`, `hash_articulo`) VALUES
('05-Seguridad-en-sistemas.pdf', 1511398874, 'seguridad en sistemas', 'susana', 'UC', '059ea5c901ca2ce9cf89e9f3ce8384ff'),
('1Convocatoria1Semestre.pdf', 1511384563, 'conv1', 'susana', 'UC', '910cb8f9651138e02609c04bbc8816f0'),
('1Convocatoria2Semestre.pdf', 1511376571, 'convo5454', 'susana', 'UC', '1af350530a74b299c01a6ebd0dac7966'),
('BUS.pdf', 1511426814, 'bus', 'javier', 'UH', '21a90234e7007d6ed8d503be2e8afe98'),
('Calendario-Academico-Oficial_2017-2018-Grado.pdf', 1511363921, 'calendario', 'susana', 'UC', '502a3ee092fe4af4376916634bf559f2'),
('EPD 09 - Entregable.pdf', 1511351072, 'epd9', 'susana', 'UC', '3c2aa47a74c1b3a8e3ceaf3a92d0ed0b'),
('EPD 10 - JMS_v2.pdf', 1511351279, 'epd10sd', 'susana', 'UC', '87f91325544af18b0c61c5608980ddfb'),
('muÃ±oz2.pdf', 1511351934, 'muÃ±oz', 'susana', 'UC', '6ef60901a9361d2d0bdebbdd16ea3f96');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `nom_usuario` varchar(20) NOT NULL,
  `clave` varchar(50) NOT NULL,
  `email` varchar(80) NOT NULL,
  `universidad` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`nom_usuario`, `clave`, `email`, `universidad`) VALUES
('javier', '3c9c03d6008a5adf42c2a55dd4a1a9f2', 'javier@gmail.com', 'UH'),
('jorge', 'd67326a22642a324aa1b0745f2f17abb', 'jorge@gmail.com', 'UJ'),
('julieta', '99d323c317a67d0133c668c525389800', 'julieta@gmail.com', 'UPO'),
('manuel', '96917805fd060e3766a9a1b834639d35', 'manuel@gmail.com', 'UIA'),
('maria', '250cf8b51c773f3f8dc8b4be867a9a02', 'maria@hotmail.com', 'UC'),
('susana', '3f06a7247d5c04d0618552dd3276ac40', 'susana@hotmail.com', 'UC');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `articulos`
--
ALTER TABLE `articulos`
  ADD PRIMARY KEY (`nom_articulo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`nom_usuario`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
