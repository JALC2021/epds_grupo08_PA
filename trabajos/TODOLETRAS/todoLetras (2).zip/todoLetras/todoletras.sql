
-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 19, 2015 at 07:17 AM
-- Server version: 5.1.57
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `a5935875_tletras`
--
CREATE DATABASE IF NOT EXISTS `todoletras` DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish_ci;
USE `todoletras`;
-- --------------------------------------------------------

--
-- Table structure for table `carro`
--

CREATE TABLE `carro` (
  `idlibro` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `autor` varchar(50) NOT NULL,
  `editorial` varchar(30) NOT NULL,
  `genero` varchar(20) NOT NULL,
  `anoedicion` int(4) NOT NULL,
  `isbn` varchar(30) NOT NULL,
  `imagen` varchar(30) NOT NULL,
  `precio` float NOT NULL,
  `usuario` varchar(10) NOT NULL,
  PRIMARY KEY (`idlibro`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `carro`
--
CREATE DATABASE IF NOT EXISTS `todoletras` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `todoletras`;
-- --------------------------------------------------------

--
-- Table structure for table `libros`
--

CREATE TABLE `libros` (
  `idlibro` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `autor` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `editorial` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `genero` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `anoedicion` int(4) NOT NULL,
  `isbn` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `imagen` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `precio` float NOT NULL,
  `ventas` float NOT NULL,
  `fechahora` datetime NOT NULL,
  PRIMARY KEY (`idlibro`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `libros`
--

INSERT INTO `libros` VALUES(1, 'Crepusculo', 'Stephenie Meyer', 'Alfaguara', 'Novela', 2005, '978-884-20-47113', 'crepusculo.jpg', 14.5, 1, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(2, 'Luna Nueva', 'Stephenie Meyer', 'Alfaguara', 'Novela', 2006, '978-8483-65-1803', 'lunanueva.jpg', 14.5, 1, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(3, 'Eclipse', 'Stephenie Meyer', 'Alfaguara', 'Novela', 2007, '978-884-20-46928', 'eclipse.jpg', 14.5, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(4, 'Amanecer', 'Stephenie Meyer', 'Alfaguara', 'Novela', 2008, '978-8420-40-6268', 'amanecer.jpg', 17.5, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(5, 'The Host', 'Stephenie Meyer', 'Suma', 'Novela', 2010, '978-842-04-72331', 'thehost.jpg', 20, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(6, 'La segunda vida de Bree Tanner', 'Stephenie Meyer', 'Alfaguara', 'Novela', 2010, '978-607-11-00334', 'breetanner.jpg', 7.9, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(7, 'Apocalypse', 'Tim Bowler', 'Sin limites', 'Novela', 2004, '978-84-9759-2907', 'apocalypse.jpg', 10, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(8, 'El simbolo perdido', 'Dan Brown', 'Booket', 'Novela', 2009, '978-84-9764-4742', 'simboloperdido.jpg', 19.6, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(9, 'Los pilares de la Tierra', 'Ken Follet', 'Debolsillo', 'Novela', 1989, '978-8437-60-7710', 'lospilaresdelatierra.jpg', 17.8, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(10, 'Cumbres Borrascosas', 'Emily Bronte', 'Edimat libros', 'Novela', 2009, '978-8437-60-7719', 'cumbresborrascosas.jpg', 5, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(11, 'Bajarse al moro', 'Jose Luis Alonso de Santos', 'Catedra', 'Novela', 2005, '978-84-08-099224', 'bajarsealmoro.jpg', 7, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(12, 'El curso en que me enamore de ti', 'Blanca Alvarez', 'Nautilus', 'Novela', 2004, '84-666-2471-6527', 'elcurso.jpg', 6.3, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(13, 'La catedral', 'Cesar Mallorqui', 'SM', 'Novela', 2000, '84-348-7239-0452', 'lacatedral.jpg', 8.5, 1, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(14, 'A tres metros sobre el cielo', 'Federico Moccia', 'Booket', 'Novela', 2012, '9788408110491', 'atresmetros.jpg', 6.99, 1, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(15, 'Tengo ganas de ti', 'Federico Moccia', 'Planeta', 'Novela', 2012, '9788408095545', 'tengoganasdeti.jpg', 9.95, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(16, 'Flor del desierto', 'Waris Dirie', 'RBA', 'Novela', 2003, '9788492695980', 'flordesierto.jpg', 8.2, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(17, 'Un burka por amor', 'Reyes Monforte', 'Temas de hoy', 'Novela', 2007, '9788484606499', 'unburkaporamor.jpg', 5.2, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(18, 'Perdona si te llamo amor', 'Federico Moccia', 'Planeta', 'Novela', 2009, '9788408101741', 'perdonasitellamo.jpg', 9.95, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(19, 'Perdona pero quiero casarme contigo', 'Federico Moccia', 'Planeta', 'Novela', 2011, '9788408101758', 'perdonaperoquiero.jpg', 9.95, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(21, 'El Jardín de Norte', 'Boris Izaguirre', 'Planeta', 'Novela', 2014, '9728408101712', 'jardin.jpg', 19.95, 0, '2015-01-18 20:47:58');
INSERT INTO `libros` VALUES(22, 'Pack Cincuenta sombras de Grey', 'E.L. James', 'Grijalbo', 'Novela', 2013, '9788425351501', 'cincuentasombras.jpg', 35.6, 0, '2015-01-18 22:12:33');
INSERT INTO `libros` VALUES(23, 'Escenas y Escenarios', 'Elena del Amo', 'Cultiva Libros', 'Novela', 2011, '9788492519590', 'escenas.jpg', 12.5, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(25, 'Las Horas Distantes', 'Kate Morton', 'Suma', 'Novela', 2012, '9788483652510', 'horas.jpg', 19.95, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(26, 'El Evangelio del Mal', 'Graham Patrick', 'Grualbo', 'Novela', 2008, '9788425342349', 'evangelio.jpg', 21, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(27, 'Hipocresia', 'Rafael San Martin', 'Cultiva Libros', 'Novela', 2011, '9788499239040', 'hipocresia.jpg', 16, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(28, 'Los Horrores del Escalpelo', 'Daniel Mares', 'Ajec', 'Novela', 2011, '9788415156123', 'horrores.jpg', 27.7, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(29, 'El Codigo Da Vinci', 'Dan Brown', 'Umbriel', 'Novela', 2004, '9788495618818', 'codigo.jpg', 36.25, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(30, 'Medianoche', 'Claudia Gray', 'Montena', 'Novela', 2008, '9788499081861', 'medianoche.jpg', 13.95, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(31, 'EL Porque de las Cosas', 'Quim Monzo', 'Anagrama', 'Novela', 2009, '9788433968289', 'monzo.jpg', 15, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(32, 'Ángeles y Demonios', 'Dan Brown', 'Umbriel', 'Novela', 2005, '9788495618771', 'angeles.jpg', 38.25, 1, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(33, 'La Conspiración', 'Dan Brown', 'Umbriel', 'Novela', 2005, '9788495618825', 'conspiracion.jpg', 15, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(34, 'El Niño con el Pijama de Rayas', 'John Boyne', 'Salamandra', 'Novela', 2007, '9788498380798', 'pijama.jpg', 13, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(35, 'El Psico-Analista', 'John Katzenbach', 'Zeta Bolsillo', 'Novela', 2009, '9788498721805', 'psicoanalista.jpg', 10, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(36, 'El Viejo y el Mar', 'Ernest Hermingway', 'Debolsillo', 'Novela', 2011, '9788499089980', 'viejo.jpg', 8.95, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(37, 'Tres Deseos', 'Miguel Blanco', 'La Esfera de los Libros', 'Novela', 2009, '9788427200272', 'deseos.jpg', 15, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(38, 'Coctel de Letras', 'Miguel Blanco', 'La Esfera de los Libros', 'Novela', 2009, '9788497348705', 'coctel.jpg', 15, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(39, 'Lunes de Ceniza', 'Miguel Blanco', 'La Esfera de los Libros', 'Novela', 2009, '9788498671438', 'ceniza.jpg', 15, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(40, 'El Cementerio de los Reflejos', 'Silvia Ibañez Cambra', 'AJEC', 'Novela', 2010, '9788415156024', 'cementerio.jpg', 20.95, 0, '2015-01-01 12:30:12');
INSERT INTO `libros` VALUES(42, 'El Boligrafo de Gel Verde', 'Eloy moreno', 'Espasa-Calpe', 'Novela', 2010, '9788467035919', 'boligrafo.jpg', 16.9, 0, '2015-01-01 12:30:12');

-- --------------------------------------------------------

--
-- Table structure for table `mensajes`
--

CREATE TABLE `mensajes` (
  `idmensa` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` char(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `fechahora` datetime NOT NULL,
  `mensaje` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idmensa`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mensajes`
--

INSERT INTO `mensajes` VALUES(1, 'patryjh', '2015-01-18 03:06:48', 'Hola, soy nueva en la comunidad. Alguién tiene el ebook de Los Juegos del Hambre?\r\nMuchas gracias.');

-- --------------------------------------------------------

--
-- Table structure for table `noticias`
--

CREATE TABLE `noticias` (
  `idnot` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `fechahora` datetime NOT NULL,
  `cuerpo` varchar(1000) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idnot`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `noticias`
--

INSERT INTO `noticias` VALUES(1, 'XXXVII Feria del Libro Antiguo de Sevilla 2014', '2015-01-18 03:23:45', 'Del viernes 14 de noviembre al lunes 8 de diciembre de 2014 tendrá lugar en Sevilla la trigésimo séptima edición de la Feria del Libro Antiguo y de Ocasión. El jueves 13 Jorge Edwards será el encargado del pregón en el Círculo Mercantil e Industrial (20:30 horas). El día de la inauguración la Banda Sinfónica Municipal ofrecerá un concierto tras el monumento a San Fernando a las 12 horas. Una edición más se podrán visitar en la Plaza Nueva los distintos expositores de librerías. Además, como actividades paralelas se ha organizado el ciclo “Libros para una educación sentimental” en la Sala Apeadero del Ayuntamiento (martes 2, miércoles 3 y jueves 4 de diciembre a las 19 horas) y cuentacuentos a las 12:30 horas los domingos 16, 23 y 30 de noviembre por Pepe Pérez.\r\nMas informacion: http://onsevilla.com/2014/11/feria-libro-antiguo-sevilla-2014.html');
INSERT INTO `noticias` VALUES(2, 'Cuenta atrás para la Feria del Libro 2014', '2015-01-18 03:43:44', 'La ciudad de Dos Hermanas estrena el próximo 12 de diciembre una nueva edición de la Feria del Libro en la Plaza del Arenal. Estará presente hasta el 5 enero y tendrá un horario de mañana (de 11:00 a 14:00 horas) y de tarde (de 16:30 a 20:30 horas). Los días 24, 31 y 5 permanecerá cerrado por la tarde, mientras que los días 25 y 1 quedará abierto en horario completo. El cartel ha sido realizado por el empresario nazareno Alejandro Santos, simbolizando la magia de la Navidad mediante un libro abierto entre la oscuridad.\r\nMas informacion: http://www.doshermanasinfo.com/cuenta-atras-para-la-feria-del-libro-2014/');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `usuario` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `contrasena` varchar(600) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(70) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `sexo` varchar(6) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `edad` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `dni` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(15) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` VALUES('admin', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', 'Administrador', 'Anonimus Anonimus', 'Hombre', '11/08/1990', '77788819Q', 'admin');
INSERT INTO `usuarios` VALUES('autor', '3ae92cf0ef4237e0c4eb512dd1fd17831d0c2316926ddea711afe520a0e5027a', 'Autor', 'Anonimus Anonimus', 'Mujer', '27/02/1991', '77269854L', 'autor');
INSERT INTO `usuarios` VALUES('patryjh', 'c4e7a992f0f7665db4f557a64669b77ac8b81475737598278c3576a140f5883c', 'Patricia', 'Jiménez Herrera', 'mujer', '27/02/1991', '77788896P', 'autor');
INSERT INTO `usuarios` VALUES('user', '04f8996da763b7a969b1028ee3007569eaf3a635486ddab211d512c85b9df8fb', 'User', 'Anonimus Anonimus', 'Mujer', '30/02/1989', '79365485K', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `ventas`
--

CREATE TABLE `ventas` (
  `idlibro` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `autor` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `editorial` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `genero` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `anoedicion` int(4) NOT NULL,
  `isbn` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `imagen` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `precio` float NOT NULL,
  `dia` float NOT NULL,
  `mes` float NOT NULL,
  `anio` float NOT NULL,
  `usuario` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idlibro`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ventas`
--

INSERT INTO `ventas` VALUES(1, 'Luna Nueva', 'Stephenie Meyer', 'Alfaguara', 'Novela', 2006, '978-8483-65-1803', 'lunanueva.jpg', 14.5, 18, 1, 2015, 'patryjh');
INSERT INTO `ventas` VALUES(2, 'Crepusculo', 'Stephenie Meyer', 'Alfaguara', 'Novela', 2005, '978-884-20-47113', 'crepusculo.jpg', 14.5, 18, 1, 2015, 'patryjh');
INSERT INTO `ventas` VALUES(3, 'A tres metros sobre el cielo', 'Federico Moccia', 'Booket', 'Novela', 2012, '9788408110491', 'atresmetros.jpg', 6.99, 18, 1, 2015, 'patryjh');
INSERT INTO `ventas` VALUES(4, 'La catedral', 'Cesar Mallorqui', 'SM', 'Novela', 2000, '84-348-7239-0452', 'lacatedral.jpg', 8.5, 18, 1, 2015, 'patryjh');
INSERT INTO `ventas` VALUES(5, 'Ángeles y Demonios', 'Dan Brown', 'Umbriel', 'Novela', 2005, '9788495618771', 'angeles.jpg', 38.25, 19, 1, 2015, 'user');
