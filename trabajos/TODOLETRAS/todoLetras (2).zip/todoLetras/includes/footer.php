<footer>
    <div class="informacion">
        <h4 class="h4footer">Informacion</h4>
        <p><a href="contacto.php">Contacto</a></p>
        <p><a href="ayuda.php">Ayuda</a></p>
    </div>
    <div class="redes">
        <h4 class="h4footer">Siguenos</h4>
        <a href="https://www.facebook.com/profile.php?id=100008911776444" target="_blank"><img src="imagenes/facebook.png" alt="Facebook" class="siguenos"/></a>
        <a href="https://twitter.com/TodLetras" target="_blank"><img src="imagenes/twitter.png" alt="Twitter" class="siguenos"/></a>
    </div>
    <div id="google_translate_element" class="traductor"></div>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'es'}, 'google_translate_element');
        }
    </script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</footer>