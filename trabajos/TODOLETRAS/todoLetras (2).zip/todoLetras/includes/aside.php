<aside>
    <div class="mas-vendidos">
        <h4 class="h4titulos">Los mas vendidos</h4>
        <ul>
            <?php
            include('masvendidos.php');
            ?>
        </ul>
    </div>
    <div class="ultimas-compras">
        <h4 class="h4titulos">Ultimas compras</h4>
        <ul>
            <?php
            include('ultimascompras.php');
            ?>
        </ul>
    </div>
</aside>