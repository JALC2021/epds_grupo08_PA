<div class="menu-sup">
    <ul>
        <li>Hola <strong style="color: #B81D22;">Invitado</strong></li>
        <li><a href="ayuda.php">Ayuda</a></li>
        <li><a href="registro.php">Registrate</a></li>
        <li><a href="login.php">Iniciar Sesi&oacute;n</a></li>
    </ul>
</div>