<div class="menu-sup">
    <ul>
        <li>Hola <strong style="color: #B81D22;"><?php echo $_SESSION['user'] ?></strong></li>
        <li><a href="ayuda.php">Ayuda</a></li>
        <li><a href="micuenta.php">Mi Cuenta</a></li>
        <li><a href="includes/cerrarsesion.php">Cerrar Sesi&oacute;n</a></li>
    </ul>
</div>